package schedulegenerator;

import javax.swing.JFrame;

/**
 * TODO Put here a description of what this class does.
 *
 * @author schneimd.
 *         Created Oct 15, 2012.
 */
public class Calendar extends JFrame{

}
