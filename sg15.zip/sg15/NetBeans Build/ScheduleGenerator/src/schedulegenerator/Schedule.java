package schedulegenerator;

/**
 * Used to store predicted days and generate new days.
 *
 * @author schneimd.
 *         Created Oct 18, 2012.
 */
public class Schedule {

}
